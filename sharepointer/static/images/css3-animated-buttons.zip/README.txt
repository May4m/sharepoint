A Pen created at CodePen.io. You can find this one at http://codepen.io/sethabbott/pen/FtuLz.

 Just playing around with transitions. No jQuery, just pure CSS3 buttons with descriptions. 